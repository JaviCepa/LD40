using UnityEngine;
using System.Collections;

namespace PlatformerPro
{

	public enum CharacterState
	{

	}

}